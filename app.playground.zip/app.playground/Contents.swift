import Cocoa

// Unique Elements in array

func uniqueElements(_ array: [Int]) -> Int {
    var uniqueArray = [Int]()
    
    for num in array {
        if !uniqueArray.contains(num) {
            uniqueArray.append(num)
        }
    }
    
    let count = uniqueArray.count
    
    return count
}

print(uniqueElements([20, 11, 20, 19, 27, 4, 0, 12, 19]))


// Intersection of arrays

func intersection(_ array1: [Int], _ array2: [Int]) -> [Int] {
    var newArray = [Int]()
    
    for num1 in array1 {
        for num2 in array2 {
            if num1 == num2 && !newArray.contains(num1){
                newArray.append(num1)
            }
        }
    }
    
    return newArray
}

print(intersection([20, 11, 20, 17, 17, 27, 12], [18, 12, 16, 28, 17, 14, 18, 11]))


// Union of arrays

func union(_ array1: [Int],_ array2: [Int]) -> [Int] {
    var newArray = [Int]()
    
    for num in array1 {
        if !newArray.contains(num) {
            newArray.append(num)
        }
    }
    
    for num1 in newArray {
        for num2 in array2 {
            if num1 != num2 && !newArray.contains(num2){
                newArray.append(num2)
            }
        }
    }
    
    return newArray
}

print(union([20, 11, 20, 17, 17, 27, 12], [18, 12, 16, 28, 17, 14, 18, 11]))
