import Cocoa


extension String {

    // Return vowel count
    func vowelCount() -> Int {
        return self.count - Array(self.lowercased()).filter { $0 != "a" }.filter { $0 != "e" }.filter { $0 != "i" }.filter { $0 != "o" }.filter { $0 != "u" }.count
    }

    // Return consonant count
    func consonantCount() -> Int {
        return self.filter{$0 != " "}.count - self.vowelCount()
    }

    // Return reversed string
    func reversedString() -> String {
        return String(self.reversed())
    }
}

var str = "Some String in Swift"

// Print vowel count
print("There are \(str.vowelCount()) vowels in this string.")

// Print consonant count
print("There are \(str.consonantCount()) consonants in this string.")

// Print reversed string
print("Reversed string: \(str.reversedString())")


protocol remainder {
    var value: Int {get}
    func remainder() -> Int
}

class A: remainder {
    var value: Int
    
    init(value: Int) {
        self.value = value
    }
    
    func remainder() -> Int {
        return self.value%10
    }
}

class B: remainder {
    var value: Int
    
    init(value: Int) {
        self.value = value
    }
    
    func remainder() -> Int {
        return self.value%10
    }
}
class C: remainder {
    var value: Int
    
    init(value: Int) {
        self.value = value
    }
    
    func remainder() -> Int {
        return self.value%10
    }
}

let Obj1 = A(value: 13)
let Obj2 = A(value: 15)
let Obj3 = A(value: 23)
let Obj4 = B(value: 25)
let Obj5 = B(value: 17)
let Obj6 = B(value: 43)
let Obj7 = C(value: 56)
let Obj8 = C(value: 60)
let Obj9 = C(value: 42)

let arr: [remainder] = [Obj1, Obj2, Obj3, Obj4, Obj5, Obj6, Obj7, Obj8, Obj9]

print(arr.reduce(0, { $0 + $1.remainder()}))
