import Cocoa

struct post {
    var id: Int
    var title: String
    var category: [String]
    var rating: Double
}

var bloggers: [blogger] = []
var postID = 0
var guestID = 1

class blogger {
    var posts: [post] = []
    var name = ""
    
    func addPost(title: String, category: [String], rating: Double) {
        var fixedRating = rating
        if fixedRating > 5 {
            fixedRating = 5
        } else if fixedRating < 0 {
            fixedRating = 0
        }
        self.posts.append(post(id: postID, title: title, category: category, rating: fixedRating))
        postID += 1
    }
    
    func listPosts() {
        if posts.count == 0 {
            print("This author has no posts yet.")
        } else {
            for post in posts {
                print("----")
                print("ID: \(String(format: "%03d", post.id))")
                print("Author: \(self.name)")
                print("Title: \(post.title)")
                print("Category: \(post.category)")
                print("Rating: \(post.rating)")
                print("----")
            }
        }
    }
    
    func averageRating() -> Double {
        if posts.count == 0 {
            return 0
        } else {
            var ratingSum: Double = 0
            for post in posts {
                ratingSum += post.rating
            }
            return ratingSum/Double(posts.count)
        }
    }
    
    func popularPost() -> String {
        var result = ""
        if posts.count == 0 {
            result = "This author has no posts yet."
        } else {
            for post in posts {
                for post2 in posts {
                    if post.rating > post2.rating {
                        result = post.title
                    }
                }
            }
        }
        return result
    }
    
    init(name: String) {
        bloggers.append(self)
        self.name = name
    }
    
    convenience init() {
        self.init(name: "Guest \(guestID)")
        guestID += 1
    }
    
}



class blogInfo {
    static func bloggerCount() -> Int {
        return bloggers.count
    }
    
    static func popularPost() -> String {
        var postTitle = ""
        var highestRating: Double = 0
        for blogger in bloggers {
            for post in blogger.posts {
                if post.rating > highestRating {
                    highestRating = post.rating
                    postTitle = post.title
                }
            }
        }
        return postTitle
    }
    
    static func popularAuthor() -> String {
        var author = ""
        var bestRating: Double = 0
        
        for blogger in bloggers {
            if bestRating < blogger.averageRating() {
                bestRating = blogger.averageRating()
                author = blogger.name
            }
        }
        
        return author
    }
    
    static func averageRating() -> Double {
        var allAverage: Double = 0
        for blogger in bloggers {
            allAverage += blogger.averageRating()
        }
        
        return allAverage/Double(bloggers.count)
    }
    
    static func popularCategory() -> String {
        var categories = [String: Int]()
        for blogger in bloggers {
            for post in blogger.posts {
                for category in post.category {
                    if categories[category] != nil {
                        categories[category]! += 1
                    } else {
                        categories[category] = 1
                    }
                }
            }
        }
        
        let popular = categories.max { a, b in a.value < b.value}
        return (popular!.key)
    }
}

let blogger1 = blogger(name: "Juan")


blogger1.addPost(title: "CDC removes guidance on drugs touted by Trump to treat coronavirus", category: ["Health"], rating: 4.9)
blogger1.addPost(title: "Wall Street logs second straight week of gains", category: ["Business"], rating: 4.2)
blogger1.addPost(title: "Facebook cancels large in-person events through June 2021", category: ["Business", "Technology"], rating: 4.7)
blogger1.addPost(title: "Taiwan's largest airline considers a name change", category: ["Travel"], rating: 3.7)


let blogger2 = blogger(name: "Maggie")


blogger2.addPost(title: "Biden says he's starting to put together a White House transition team", category: ["Politics"], rating: 3.5)
blogger2.addPost(title: "Trump ally Michael Caputo named as new HHS spokesperson", category: ["Politics"], rating: 4.2)
// Blogger class fixes ratings that are > 5 && < 0
blogger2.addPost(title: "Oil crashes below $19, falling to an 18-year low", category: ["Business"], rating: 5.5)
blogger2.addPost(title: "Tennis may not survive' coronavirus pandemic", category: ["Sports"], rating: 3.6)

// List bloggers posts
blogger1.listPosts()
blogger2.listPosts()

// Average rating for blogger Juan
print("Average rating for all posts by \(blogger1.name): \(blogger1.averageRating())")

// Most popular post by Juan
print("Most popular post by \(blogger1.name) is: '\(blogger1.popularPost())'")

// Bloggers count
print("There \(blogInfo.bloggerCount() == 1 ? "is" : "are") \(bloggers.count) \(bloggers.count == 1 ? "blogger" : "bloggers") on this blog")

// Most popular post on the blog
print("The most popular post on the blog is '\(blogInfo.popularPost())'")

// Most popular blogger on the blog
print("The most popular blogger is \(blogInfo.popularAuthor())")

// Average rating on blog
print("Average rating on the blog is \(blogInfo.averageRating())")

// Most used category on blog
print("Most used category on the blog is '\(blogInfo.popularCategory())'")
